package com.chat;

//@RunWith(SpringJUnit4ClassRunner.class)
//@SpringApplicationConfiguration(classes = CommunicatorApplication.class)
public class ChatApplicationTests {

//  @Test
  public void contextLoads() {}

}
