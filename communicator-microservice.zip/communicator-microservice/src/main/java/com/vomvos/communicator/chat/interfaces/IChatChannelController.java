package com.vomvos.communicator.chat.interfaces;

import org.springframework.beans.BeansException;
import org.springframework.http.ResponseEntity;
import org.springframework.messaging.handler.annotation.DestinationVariable;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import com.vomvos.communicator.chat.DTOs.ChatChannelInitializationDTO;
import com.vomvos.communicator.chat.DTOs.ChatMessageDTO;
import com.vomvos.communicator.user.exceptions.IsSameUserException;
import com.vomvos.communicator.user.exceptions.UserNotFoundException;

public interface IChatChannelController {
    ChatMessageDTO chatMessage(@DestinationVariable String channelId, ChatMessageDTO message)
        throws BeansException, UserNotFoundException;

    ResponseEntity<String> establishChatChannel(@RequestBody ChatChannelInitializationDTO chatChannelInitialization)
        throws IsSameUserException, UserNotFoundException; 

    ResponseEntity<String> getExistingChatMessages(@PathVariable("channelUuid") String channelUuid);
}
