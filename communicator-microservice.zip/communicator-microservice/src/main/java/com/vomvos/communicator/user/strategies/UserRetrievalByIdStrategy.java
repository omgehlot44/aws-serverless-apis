package com.vomvos.communicator.user.strategies;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vomvos.communicator.user.models.User;
import com.vomvos.communicator.user.repositories.UserRepository;

@Service
public class UserRetrievalByIdStrategy implements IUserRetrievalStrategy<Long> {
  private UserRepository userRepository;

  @Autowired
  public UserRetrievalByIdStrategy(UserRepository userRepository) {
    this.userRepository = userRepository;
  }

  @Override
  public User getUser(Long userIdentifier) {
    return userRepository.findById(userIdentifier);
  }
}
