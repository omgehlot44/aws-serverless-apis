package com.vomvos.communicator.user.controllers;

import org.springframework.messaging.handler.annotation.DestinationVariable;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.web.bind.annotation.*;

import com.vomvos.communicator.user.interfaces.INotificationController;

@RestController
public class NotificationController implements INotificationController {

  @SendTo("/topic/user.notification.{userId}")
  public String notifications(@DestinationVariable long userId, String message) {
    return message;
  }
}