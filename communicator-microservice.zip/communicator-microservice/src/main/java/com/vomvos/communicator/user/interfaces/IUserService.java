package com.vomvos.communicator.user.interfaces;

import java.util.List;

import org.springframework.beans.BeansException;
import org.springframework.security.core.context.SecurityContext;

import com.vomvos.communicator.shared.exceptions.ValidationException;
import com.vomvos.communicator.user.DTOs.NotificationDTO;
import com.vomvos.communicator.user.DTOs.RegistrationDTO;
import com.vomvos.communicator.user.DTOs.UserDTO;
import com.vomvos.communicator.user.exceptions.UserNotFoundException;
import com.vomvos.communicator.user.models.User;

public interface IUserService {
  User getUser(String userEmail)
      throws BeansException, UserNotFoundException;

  User getUser(long userId)
      throws BeansException, UserNotFoundException;

  User getUser(SecurityContext securityContext)
      throws BeansException, UserNotFoundException;

  boolean doesUserExist(String email);

  void addUser(RegistrationDTO registrationDTO)
      throws ValidationException;

  List<UserDTO> retrieveFriendsList(User user);

  UserDTO retrieveUserInfo(User user);

  void setIsPresent(User user, Boolean stat);

  Boolean isPresent(User user);

  void notifyUser(User user, NotificationDTO notification);
}