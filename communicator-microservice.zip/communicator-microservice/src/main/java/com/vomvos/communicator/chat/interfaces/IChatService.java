package com.vomvos.communicator.chat.interfaces;

import java.util.List;

import org.springframework.beans.BeansException;

import com.vomvos.communicator.chat.DTOs.ChatChannelInitializationDTO;
import com.vomvos.communicator.chat.DTOs.ChatMessageDTO;
import com.vomvos.communicator.user.exceptions.IsSameUserException;
import com.vomvos.communicator.user.exceptions.UserNotFoundException;

public interface IChatService {
  String establishChatSession(ChatChannelInitializationDTO chatChannelInitializationDTO)
      throws IsSameUserException, BeansException, UserNotFoundException;

  void submitMessage(ChatMessageDTO chatMessageDTO)
      throws BeansException, UserNotFoundException;
  
  List<ChatMessageDTO> getExistingChatMessages(String channelUuid);
}