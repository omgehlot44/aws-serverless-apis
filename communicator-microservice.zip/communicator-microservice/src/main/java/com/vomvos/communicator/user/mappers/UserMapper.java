package com.vomvos.communicator.user.mappers;

import java.util.ArrayList;
import java.util.List;

import com.vomvos.communicator.user.DTOs.UserDTO;
import com.vomvos.communicator.user.models.User;

public class UserMapper {
  public static List<UserDTO> mapUsersToUserDTOs(List<User> users) {
    List<UserDTO> dtos = new ArrayList<UserDTO>();

    for(User user : users) {
      dtos.add(
        new UserDTO(
          user.getId(),
          user.getEmail(),
          user.getFullName()
        )
      );
    }

    return dtos;
  }
}