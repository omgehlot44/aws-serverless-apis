package com.vomvos.communicator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.session.data.redis.config.annotation.web.http.EnableRedisHttpSession;

import com.vomvos.communicator.shared.security.ApplicationSecurity;

@SpringBootApplication
@EnableRedisHttpSession
public class CommunicatorApplication {
  @Bean
  public WebSecurityConfigurerAdapter webSecurityConfigurerAdapter() {
    return new ApplicationSecurity();
  }

  public static void main(String[] args) {
    // mvn spring-boot:run -Drun.jvmArguments='-Dserver.port={PORT}'
    SpringApplication.run(CommunicatorApplication.class, args);
  }
}