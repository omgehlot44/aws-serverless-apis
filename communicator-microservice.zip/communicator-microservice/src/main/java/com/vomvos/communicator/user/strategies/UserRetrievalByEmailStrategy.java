package com.vomvos.communicator.user.strategies;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vomvos.communicator.user.models.User;
import com.vomvos.communicator.user.repositories.UserRepository;

@Service
public class UserRetrievalByEmailStrategy implements IUserRetrievalStrategy<String> {
  private UserRepository userRepository;

  @Autowired
  public UserRetrievalByEmailStrategy(UserRepository userRepository) {
    this.userRepository = userRepository;
  }

  @Override
  public User getUser(String userIdentifier) {
    return userRepository.findByEmail(userIdentifier);
  }
}