package com.vomvos.communicator.user.strategies;

import com.vomvos.communicator.user.models.User;

public interface IUserRetrievalStrategy<T> {
  public User getUser(T userIdentifier);
}