package com.vomvos.communicator.user.controllers;

import java.security.Principal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import com.vomvos.communicator.shared.exceptions.ValidationException;
import com.vomvos.communicator.shared.http.JSONResponseHelper;
import com.vomvos.communicator.user.DTOs.RegistrationDTO;
import com.vomvos.communicator.user.DTOs.UserDTO;
import com.vomvos.communicator.user.exceptions.UserNotFoundException;
import com.vomvos.communicator.user.interfaces.IUserController;
import com.vomvos.communicator.user.models.User;
import com.vomvos.communicator.user.services.UserService;

@RestController
public class UserController implements IUserController {
  @Autowired
  private UserService userService;

  @RequestMapping(value="/api/user/register", method= RequestMethod.POST, produces="application/json", consumes="application/json")
  public ResponseEntity<String> register(@RequestBody RegistrationDTO registeringUser)
      throws ValidationException {
    userService.addUser(registeringUser);

    return JSONResponseHelper.createResponse("", HttpStatus.OK);
  }

  // TODO: actually implement concept of a "friendslist"
  @RequestMapping(value="/api/user/requesting/friendslist", method=RequestMethod.GET, produces="application/json")
  public ResponseEntity<String> retrieveRequestingUserFriendsList(Principal principal)
      throws UserNotFoundException {
    User requestingUser = userService.getUser(SecurityContextHolder.getContext());
    List<UserDTO> friendslistUsers = userService.retrieveFriendsList(requestingUser);
 
    return JSONResponseHelper.createResponse(friendslistUsers, HttpStatus.OK);
  }

  @RequestMapping(value="/api/user/requesting/info", method=RequestMethod.GET, produces="application/json")
  public ResponseEntity<String> retrieveRequestUserInfo()
      throws UserNotFoundException {
    User requestingUser = userService.getUser(SecurityContextHolder.getContext());
    UserDTO userDetails = userService.retrieveUserInfo(requestingUser);

    return JSONResponseHelper.createResponse(userDetails, HttpStatus.OK);
  }
}