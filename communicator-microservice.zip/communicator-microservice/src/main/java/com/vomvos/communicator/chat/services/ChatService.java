package com.vomvos.communicator.chat.services;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import com.google.common.collect.Lists;
import com.vomvos.communicator.chat.DTOs.ChatChannelInitializationDTO;
import com.vomvos.communicator.chat.DTOs.ChatMessageDTO;
import com.vomvos.communicator.chat.interfaces.IChatService;
import com.vomvos.communicator.chat.mappers.ChatMessageMapper;
import com.vomvos.communicator.chat.models.ChatChannel;
import com.vomvos.communicator.chat.models.ChatMessage;
import com.vomvos.communicator.chat.repositories.ChatChannelRepository;
import com.vomvos.communicator.chat.repositories.ChatMessageRepository;
import com.vomvos.communicator.user.DTOs.NotificationDTO;
import com.vomvos.communicator.user.exceptions.IsSameUserException;
import com.vomvos.communicator.user.exceptions.UserNotFoundException;
import com.vomvos.communicator.user.models.User;
import com.vomvos.communicator.user.services.UserService;

import java.util.List;

@Service
public class ChatService implements IChatService {
  private ChatChannelRepository chatChannelRepository;

  private ChatMessageRepository chatMessageRepository;

  private UserService userService;
  
  private final int MAX_PAGABLE_CHAT_MESSAGES = 100;

  @Autowired
  public ChatService(
      ChatChannelRepository chatChannelRepository,
      ChatMessageRepository chatMessageRepository,
      UserService userService) {
    this.chatChannelRepository = chatChannelRepository;
    this.chatMessageRepository = chatMessageRepository;
    this.userService = userService;
  }

  private String getExistingChannel(ChatChannelInitializationDTO chatChannelInitializationDTO) {
    List<ChatChannel> channel = chatChannelRepository
      .findExistingChannel(
        chatChannelInitializationDTO.getUserIdOne(),
        chatChannelInitializationDTO.getUserIdTwo()
      );
    
    return (channel != null && !channel.isEmpty()) ? channel.get(0).getUuid() : null;
  }

  private String newChatSession(ChatChannelInitializationDTO chatChannelInitializationDTO)
      throws BeansException, UserNotFoundException {
    ChatChannel channel = new ChatChannel(
      userService.getUser(chatChannelInitializationDTO.getUserIdOne()),
      userService.getUser(chatChannelInitializationDTO.getUserIdTwo())
    );
    
    chatChannelRepository.save(channel);

    return channel.getUuid();
  }

  public String establishChatSession(ChatChannelInitializationDTO chatChannelInitializationDTO)
      throws IsSameUserException, BeansException, UserNotFoundException {
    if (chatChannelInitializationDTO.getUserIdOne() == chatChannelInitializationDTO.getUserIdTwo()) {
      throw new IsSameUserException();
    }

    String uuid = getExistingChannel(chatChannelInitializationDTO);

    // If channel doesn't already exist, create a new one
    return (uuid != null) ? uuid : newChatSession(chatChannelInitializationDTO);
  }
  
  public void submitMessage(ChatMessageDTO chatMessageDTO)
      throws BeansException, UserNotFoundException {
    ChatMessage chatMessage = ChatMessageMapper.mapChatDTOtoMessage(chatMessageDTO);

    chatMessageRepository.save(chatMessage);

    User fromUser = userService.getUser(chatMessage.getAuthorUser().getId());
    User recipientUser = userService.getUser(chatMessage.getRecipientUser().getId());
      
    userService.notifyUser(recipientUser,
      new NotificationDTO(
        "ChatMessageNotification",
        fromUser.getFullName() + " has sent you a message",
        chatMessage.getAuthorUser().getId()
      )
    );
  }
 
  public List<ChatMessageDTO> getExistingChatMessages(String channelUuid) {
    ChatChannel channel = chatChannelRepository.getChannelDetails(channelUuid);

    List<ChatMessage> chatMessages = 
      chatMessageRepository.getExistingChatMessages(
        channel.getUserOne().getId(),
        channel.getUserTwo().getId(),
        new PageRequest(0, MAX_PAGABLE_CHAT_MESSAGES)
      );

    // TODO: fix this
    List<ChatMessage> messagesByLatest = Lists.reverse(chatMessages); 

    return ChatMessageMapper.mapMessagesToChatDTOs(messagesByLatest);
  }
}