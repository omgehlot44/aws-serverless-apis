package com.vomvos.communicator.user.interfaces;

import java.security.Principal;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;

import com.vomvos.communicator.shared.exceptions.ValidationException;
import com.vomvos.communicator.user.DTOs.RegistrationDTO;
import com.vomvos.communicator.user.exceptions.UserNotFoundException;

public interface IUserController {
  ResponseEntity<String> register(@RequestBody RegistrationDTO registeringUser)
      throws ValidationException;

  ResponseEntity<String> retrieveRequestingUserFriendsList(Principal principal)
      throws UserNotFoundException;

  ResponseEntity<String> retrieveRequestUserInfo()
      throws UserNotFoundException;
}
